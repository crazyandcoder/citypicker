package com.lljjcoder.style.cityjd;

public class JDConst {

    public static final int INDEX_TAB_PROVINCE = 0;
    public static final int INDEX_TAB_CITY = 1;
    public static final int INDEX_TAB_AREA = 2;

    public static final int INDEX_INVALID = -1;

}
