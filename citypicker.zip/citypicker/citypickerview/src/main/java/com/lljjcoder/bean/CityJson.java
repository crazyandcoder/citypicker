package com.lljjcoder.bean;

public class CityJson {
}
